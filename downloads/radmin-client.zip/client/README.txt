Клиентская копия Radmin VPN с собственным публичным ключом

Нужен установленный Radmin VPN 2.1.4951.1 из вашего установщика.
Изменённый EXE и неизменённые DLL собираются в отдельную папку командой:

powershell -NoProfile -File .\Start-RadminLabClient.ps1 -PatchedServicePath .\RvControlSvc-own-key-research.exe -PatchReportPath .\client-key-copy.json

Это подготовка без запуска. /run и требования к отдельной тестовой Windows
описаны в modified-client.md. Подпись изготовителя изменённого EXE недействительна.
Проверки Windows и проверки аутентификации в коде не отключались.
Приватного серверного RSA-ключа в этом клиентском архиве нет.
Существующая облачная регистрация не соответствует автоматически SRP-записи сервера.
На настоящей Windows эта копия ещё не запускалась; полный VPN пока не работает.

В runtime находится изменённый RvControlSvc.exe и неизменённые зависимые DLL.
Для настройки адреса на отдельной Windows (служба/GUI уже остановлены),
в PowerShell администратора:

powershell -NoProfile -File .\Set-RadminLabAddress.ps1 -ServerAddress <IP-сервера> -BackupPath .\server-address-backup.json -DedicatedTestMachine

Откат адреса:
powershell -NoProfile -File .\Set-RadminLabAddress.ps1 -Restore -BackupPath .\server-address-backup.json -DedicatedTestMachine

Затем подготовка и запуск отдельной копии:
powershell -NoProfile -File .\Start-RadminLabClient.ps1 -PatchedServicePath .\RvControlSvc-own-key-research.exe -PatchReportPath .\client-key-copy.json -ExpectedServerAddress <IP-сервера> -RunOnDedicatedTestMachine

Запуск с этой командой НЕ создаёт согласованную регистрацию автоматически.
В предоставленном серверном архиве используется синтетическая SRP-запись42.
Для исходного приложения с другим профилем сервер отклонит SRP-аутентификацию.
Ни регистрация/пароли, ни настройки доверия Windows этими скриптами не обходятся.
